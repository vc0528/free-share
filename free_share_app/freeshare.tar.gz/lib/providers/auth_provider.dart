import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  
  User? _user;
  UserModel? _userData;
  bool _isLoading = false;
  String? _error;

  User? get user => _user;
  UserModel? get userData => _userData;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _user != null;

  AuthProvider() {
    _init();
  }

  void _init() {
    _authService.authStateChanges.listen((User? user) {
      _user = user;
      if (user != null) {
        _loadUserData();
      } else {
        _userData = null;
      }
      notifyListeners();
    });
  }

  Future<void> _loadUserData() async {
    if (_user != null) {
      _userData = await _authService.getCurrentUserData();
      notifyListeners();
    }
  }

  Future<bool> signIn(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      UserCredential? result = await _authService
          .signInWithEmailAndPassword(email, password);
      
      _isLoading = false;
      notifyListeners();
      return result != null;
    } catch (e) {
      _error = _getErrorMessage(e);
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> signUp(String email, String password, String username) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      UserCredential? result = await _authService
          .createUserWithEmailAndPassword(email, password, username);
      
      _isLoading = false;
      notifyListeners();
      return result != null;
    } catch (e) {
      _error = _getErrorMessage(e);
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> signOut() async {
    await _authService.signOut();
    _user = null;
    _userData = null;
    notifyListeners();
  }

  Future<void> updateLocation(double latitude, double longitude) async {
    await _authService.updateUserLocation(latitude, longitude);
    await _loadUserData();
  }

  String _getErrorMessage(dynamic error) {
    if (error is FirebaseAuthException) {
      switch (error.code) {
        case 'user-not-found':
          return '找不到該用戶';
        case 'wrong-password':
          return '密碼錯誤';
        case 'email-already-in-use':
          return 'Email已被使用';
        case 'weak-password':
          return '密碼太弱';
        case 'invalid-email':
          return 'Email格式錯誤';
        default:
          return error.message ?? '發生未知錯誤';
      }
    }
    return error.toString();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
