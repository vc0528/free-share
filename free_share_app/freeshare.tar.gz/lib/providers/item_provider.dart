import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/item_model.dart';
import '../services/item_service.dart';

class ItemProvider extends ChangeNotifier {
  final ItemService _itemService = ItemService();
  
  List<ItemModel> _nearbyItems = [];
  List<ItemModel> _userItems = [];
  bool _isLoading = false;
  String? _error;

  List<ItemModel> get nearbyItems => _nearbyItems;
  List<ItemModel> get userItems => _userItems;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<String?> addItem({
    required String ownerId,
    required String title,
    required String description,
    required String tag,
    required List<File> imageFiles,
    required double latitude,
    required double longitude,
    String? address,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      String itemId = await _itemService.addItem(
        ownerId: ownerId,
        title: title,
        description: description,
        tag: tag,
        imageFiles: imageFiles,
        latitude: latitude,
        longitude: longitude,
        address: address,
      );
      
      _isLoading = false;
      notifyListeners();
      return itemId;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  Future<void> loadNearbyItems(double latitude, double longitude) async {
    _isLoading = true;
    notifyListeners();

    try {
      _nearbyItems = await _itemService.getNearbyItems(latitude, longitude, 2.0);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadUserItems(String userId) async {
    _isLoading = true;
    notifyListeners();

    try {
      _userItems = await _itemService.getUserItems(userId);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<ItemModel?> getItemById(String itemId) async {
    return await _itemService.getItemById(itemId);
  }

  Future<void> reportItem(String itemId, String reporterId, String reason) async {
    try {
      await _itemService.reportItem(itemId, reporterId, reason);
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
