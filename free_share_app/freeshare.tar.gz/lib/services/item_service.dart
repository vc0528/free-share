import 'dart:io';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:uuid/uuid.dart';
import '../models/item_model.dart';

class ItemService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final GeoFlutterFire _geo = GeoFlutterFire();

  Future<String> addItem({
    required String ownerId,
    required String title,
    required String description,
    required String tag,
    required List<File> imageFiles,
    required double latitude,
    required double longitude,
    String? address,
  }) async {
    try {
      String itemId = Uuid().v4();
      
      // 上傳圖片
      List<String> imageUrls = await _uploadImages(itemId, imageFiles);
      
      // 位置模糊化
      LocationData originalLocation = LocationData(
        latitude: latitude,
        longitude: longitude,
        address: address,
      );
      
      LocationData fuzzyLocation = _addRandomOffset(originalLocation);
      
      // 計算 GeoHash
      GeoFirePoint geoPoint = _geo.point(
        latitude: originalLocation.latitude,
        longitude: originalLocation.longitude,
      );
      
      ItemModel item = ItemModel(
        id: itemId,
        ownerId: ownerId,
        title: title,
        description: description,
        tag: tag,
        imageUrls: imageUrls,
        location: fuzzyLocation,
        originalLocation: originalLocation,
        createdAt: DateTime.now(),
        geoHash: geoPoint.hash,
      );

      await _firestore
          .collection('items')
          .doc(itemId)
          .set(item.toFirestore());

      return itemId;
    } catch (e) {
      throw e;
    }
  }

  LocationData _addRandomOffset(LocationData originalLocation) {
    final random = Random();
    // 約200m的緯度偏移 (1度緯度≈111km)
    double latOffset = (random.nextDouble() - 0.5) * 2 * (0.2 / 111);
    // 約200m的經度偏移 (根據緯度調整)
    double lonOffset = (random.nextDouble() - 0.5) * 2 * 
        (0.2 / (111 * cos(originalLocation.latitude * pi / 180)));
    
    return LocationData(
      latitude: originalLocation.latitude + latOffset,
      longitude: originalLocation.longitude + lonOffset,
      address: originalLocation.address,
    );
  }

  Future<List<String>> _uploadImages(String itemId, List<File> imageFiles) async {
    List<String> urls = [];
    
    for (int i = 0; i < imageFiles.length; i++) {
      String fileName = '${itemId}_$i.jpg';
      Reference ref = _storage.ref().child('items/$itemId/$fileName');
      
      UploadTask uploadTask = ref.putFile(imageFiles[i]);
      TaskSnapshot snapshot = await uploadTask;
      String url = await snapshot.ref.getDownloadURL();
      urls.add(url);
    }
    
    return urls;
  }

  Future<List<ItemModel>> getNearbyItems(
      double latitude, double longitude, double radiusInKm) async {
    try {
      GeoFirePoint center = _geo.point(latitude: latitude, longitude: longitude);
      
      Stream<List<DocumentSnapshot>> stream = _geo
          .collection(collectionRef: _firestore.collection('items'))
          .within(center: center, radius: radiusInKm, field: 'geoHash');
      
      List<DocumentSnapshot> snapshots = await stream.first;
      
      return snapshots.map((doc) => ItemModel.fromFirestore(doc)).toList();
    } catch (e) {
      print('Error getting nearby items: $e');
      return [];
    }
  }

  Future<ItemModel?> getItemById(String itemId) async {
    try {
      DocumentSnapshot doc = await _firestore
          .collection('items')
          .doc(itemId)
          .get();
      
      if (doc.exists) {
        return ItemModel.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      print('Error getting item: $e');
      return null;
    }
  }

  Future<List<ItemModel>> getUserItems(String userId) async {
    try {
      QuerySnapshot query = await _firestore
          .collection('items')
          .where('ownerId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      return query.docs.map((doc) => ItemModel.fromFirestore(doc)).toList();
    } catch (e) {
      print('Error getting user items: $e');
      return [];
    }
  }

  Future<void> updateItemStatus(String itemId, String status) async {
    await _firestore.collection('items').doc(itemId).update({
      'status': status,
      'isAvailable': status == 'active',
    });
  }

  Future<void> reportItem(String itemId, String reporterId, String reason) async {
    // 增加檢舉計數
    await _firestore.collection('items').doc(itemId).update({
      'reportCount': FieldValue.increment(1),
      'isReported': true,
    });

    // 創建檢舉記錄
    String reportId = Uuid().v4();
    await _firestore.collection('reports').doc(reportId).set({
      'id': reportId,
      'reporterId': reporterId,
      'targetType': 'item',
      'targetId': itemId,
      'reason': reason,
      'status': 'pending',
      'createdAt': Timestamp.now(),
    });
  }
}
