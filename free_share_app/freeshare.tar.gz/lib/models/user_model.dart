import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String email;
  final String username;
  final DateTime createdAt;
  final DateTime lastActive;
  final LocationData? location;
  final RatingData rating;
  final TransactionStats transactionStats;
  final UserPreferences preferences;
  final bool isAdmin;
  final bool isBanned;

  UserModel({
    required this.uid,
    required this.email,
    required this.username,
    required this.createdAt,
    required this.lastActive,
    this.location,
    required this.rating,
    required this.transactionStats,
    required this.preferences,
    this.isAdmin = false,
    this.isBanned = false,
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    
    return UserModel(
      uid: doc.id,
      email: data['email'] ?? '',
      username: data['username'] ?? '',
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      lastActive: (data['lastActive'] as Timestamp).toDate(),
      location: data['location'] != null 
          ? LocationData.fromMap(data['location']) 
          : null,
      rating: RatingData.fromMap(data['rating'] ?? {}),
      transactionStats: TransactionStats.fromMap(data['transactionStats'] ?? {}),
      preferences: UserPreferences.fromMap(data['preferences'] ?? {}),
      isAdmin: data['isAdmin'] ?? false,
      isBanned: data['isBanned'] ?? false,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'email': email,
      'username': username,
      'createdAt': Timestamp.fromDate(createdAt),
      'lastActive': Timestamp.fromDate(lastActive),
      'location': location?.toMap(),
      'rating': rating.toMap(),
      'transactionStats': transactionStats.toMap(),
      'preferences': preferences.toMap(),
      'isAdmin': isAdmin,
      'isBanned': isBanned,
    };
  }
}

class LocationData {
  final double latitude;
  final double longitude;
  final DateTime lastUpdated;

  LocationData({
    required this.latitude,
    required this.longitude,
    required this.lastUpdated,
  });

  factory LocationData.fromMap(Map<String, dynamic> map) {
    return LocationData(
      latitude: map['latitude']?.toDouble() ?? 0.0,
      longitude: map['longitude']?.toDouble() ?? 0.0,
      lastUpdated: (map['lastUpdated'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'latitude': latitude,
      'longitude': longitude,
      'lastUpdated': Timestamp.fromDate(lastUpdated),
    };
  }
}

class RatingData {
  final double averageScore;
  final int totalRatings;
  final int totalTransactions;

  RatingData({
    this.averageScore = 0.0,
    this.totalRatings = 0,
    this.totalTransactions = 0,
  });

  factory RatingData.fromMap(Map<String, dynamic> map) {
    return RatingData(
      averageScore: map['averageScore']?.toDouble() ?? 0.0,
      totalRatings: map['totalRatings'] ?? 0,
      totalTransactions: map['totalTransactions'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'averageScore': averageScore,
      'totalRatings': totalRatings,
      'totalTransactions': totalTransactions,
    };
  }
}

class TransactionStats {
  final int totalGiven;
  final int totalReceived;
  final int totalPosted;
  final int recentReceivedCount;
  final DateTime joinDate;
  final DateTime? lastTransactionDate;

  TransactionStats({
    this.totalGiven = 0,
    this.totalReceived = 0,
    this.totalPosted = 0,
    this.recentReceivedCount = 0,
    required this.joinDate,
    this.lastTransactionDate,
  });

  factory TransactionStats.fromMap(Map<String, dynamic> map) {
    return TransactionStats(
      totalGiven: map['totalGiven'] ?? 0,
      totalReceived: map['totalReceived'] ?? 0,
      totalPosted: map['totalPosted'] ?? 0,
      recentReceivedCount: map['recentReceivedCount'] ?? 0,
      joinDate: map['joinDate'] != null 
          ? (map['joinDate'] as Timestamp).toDate()
          : DateTime.now(),
      lastTransactionDate: map['lastTransactionDate'] != null
          ? (map['lastTransactionDate'] as Timestamp).toDate()
          : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'totalGiven': totalGiven,
      'totalReceived': totalReceived,
      'totalPosted': totalPosted,
      'recentReceivedCount': recentReceivedCount,
      'joinDate': Timestamp.fromDate(joinDate),
      'lastTransactionDate': lastTransactionDate != null
          ? Timestamp.fromDate(lastTransactionDate!)
          : null,
    };
  }
}

class UserPreferences {
  final int maxDailyReceive;
  final bool publicProfile;

  UserPreferences({
    this.maxDailyReceive = 2,
    this.publicProfile = true,
  });

  factory UserPreferences.fromMap(Map<String, dynamic> map) {
    return UserPreferences(
      maxDailyReceive: map['maxDailyReceive'] ?? 2,
      publicProfile: map['publicProfile'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'maxDailyReceive': maxDailyReceive,
      'publicProfile': publicProfile,
    };
  }
}
