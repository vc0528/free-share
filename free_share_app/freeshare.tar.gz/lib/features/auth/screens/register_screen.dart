import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class RegisterScreen extends StatelessWidget {
  final TextEditingController emailC = TextEditingController();
  final TextEditingController passC = TextEditingController();
  final TextEditingController nameC = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text("註冊")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: emailC, decoration: InputDecoration(labelText: "Email")),
            TextField(controller: passC, decoration: InputDecoration(labelText: "Password"), obscureText: true),
            TextField(controller: nameC, decoration: InputDecoration(labelText: "Username")),
            ElevatedButton(
              onPressed: () async {
                await auth.register(emailC.text, passC.text, nameC.text);
                Navigator.pop(context);
              },
              child: Text("註冊"),
            ),
          ],
        ),
      ),
    );
  }
}

