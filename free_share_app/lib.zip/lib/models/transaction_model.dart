import 'package:cloud_firestore/cloud_firestore.dart';

class TransactionModel {
  final String id;
  final String itemId;
  final String giverId;
  final String receiverId;
  final String chatRoomId;
  final String status; // initiated, in_progress, completed, cancelled
  final String itemTitle;
  final String itemTag;
  final String? itemImageUrl;
  final LocationData? location;
  final DateTime initiatedAt;
  final DateTime? completedAt;
  final DateTime? cancelledAt;
  final String? cancelReason;
  final String? completedBy;

  TransactionModel({
    required this.id,
    required this.itemId,
    required this.giverId,
    required this.receiverId,
    required this.chatRoomId,
    required this.status,
    required this.itemTitle,
    required this.itemTag,
    this.itemImageUrl,
    this.location,
    required this.initiatedAt,
    this.completedAt,
    this.cancelledAt,
    this.cancelReason,
    this.completedBy,
  });

  factory TransactionModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    
    return TransactionModel(
      id: doc.id,
      itemId: data['itemId'] ?? '',
      giverId: data['giverId'] ?? '',
      receiverId: data['receiverId'] ?? '',
      chatRoomId: data['chatRoomId'] ?? '',
      status: data['status'] ?? 'initiated',
      itemTitle: data['itemTitle'] ?? '',
      itemTag: data['itemTag'] ?? '',
      itemImageUrl: data['itemImageUrl'],
      location: data['location'] != null 
          ? LocationData.fromMap(data['location']) 
          : null,
      initiatedAt: (data['initiatedAt'] as Timestamp).toDate(),
      completedAt: data['completedAt'] != null
          ? (data['completedAt'] as Timestamp).toDate()
          : null,
      cancelledAt: data['cancelledAt'] != null
          ? (data['cancelledAt'] as Timestamp).toDate()
          : null,
      cancelReason: data['cancelReason'],
      completedBy: data['completedBy'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'itemId': itemId,
      'giverId': giverId,
      'receiverId': receiverId,
      'chatRoomId': chatRoomId,
      'status': status,
      'itemTitle': itemTitle,
      'itemTag': itemTag,
      'itemImageUrl': itemImageUrl,
      'location': location?.toMap(),
      'initiatedAt': Timestamp.fromDate(initiatedAt),
      'completedAt': completedAt != null 
          ? Timestamp.fromDate(completedAt!) 
          : null,
      'cancelledAt': cancelledAt != null 
          ? Timestamp.fromDate(cancelledAt!) 
          : null,
      'cancelReason': cancelReason,
      'completedBy': completedBy,
    };
  }
}

class LocationData {
  final double latitude;
  final double longitude;
  final String? address;

  LocationData({
    required this.latitude,
    required this.longitude,
    this.address,
  });

  factory LocationData.fromMap(Map<String, dynamic> map) {
    return LocationData(
      latitude: map['latitude']?.toDouble() ?? 0.0,
      longitude: map['longitude']?.toDouble() ?? 0.0,
      address: map['address'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'latitude': latitude,
      'longitude': longitude,
      'address': address,
    };
  }
}
