import 'package:cloud_firestore/cloud_firestore.dart';

class ItemModel {
  final String id;
  final String ownerId;
  final String title;
  final String description;
  final String tag;
  final List<String> imageUrls;
  final LocationData location;
  final LocationData originalLocation;
  final DateTime createdAt;
  final bool isAvailable;
  final String geoHash;
  final int reportCount;
  final bool isReported;
  final String status; // active, reported, removed, completed

  ItemModel({
    required this.id,
    required this.ownerId,
    required this.title,
    required this.description,
    required this.tag,
    required this.imageUrls,
    required this.location,
    required this.originalLocation,
    required this.createdAt,
    this.isAvailable = true,
    required this.geoHash,
    this.reportCount = 0,
    this.isReported = false,
    this.status = 'active',
  });

  factory ItemModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    
    return ItemModel(
      id: doc.id,
      ownerId: data['ownerId'] ?? '',
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      tag: data['tag'] ?? '',
      imageUrls: List<String>.from(data['imageUrls'] ?? []),
      location: LocationData.fromMap(data['location']),
      originalLocation: LocationData.fromMap(data['originalLocation']),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      isAvailable: data['isAvailable'] ?? true,
      geoHash: data['geoHash'] ?? '',
      reportCount: data['reportCount'] ?? 0,
      isReported: data['isReported'] ?? false,
      status: data['status'] ?? 'active',
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'ownerId': ownerId,
      'title': title,
      'description': description,
      'tag': tag,
      'imageUrls': imageUrls,
      'location': location.toMap(),
      'originalLocation': originalLocation.toMap(),
      'createdAt': Timestamp.fromDate(createdAt),
      'isAvailable': isAvailable,
      'geoHash': geoHash,
      'reportCount': reportCount,
      'isReported': isReported,
      'status': status,
    };
  }
}

class LocationData {
  final double latitude;
  final double longitude;
  final String? address;

  LocationData({
    required this.latitude,
    required this.longitude,
    this.address,
  });

  factory LocationData.fromMap(Map<String, dynamic> map) {
    return LocationData(
      latitude: map['latitude']?.toDouble() ?? 0.0,
      longitude: map['longitude']?.toDouble() ?? 0.0,
      address: map['address'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'latitude': latitude,
      'longitude': longitude,
      'address': address,
    };
  }
}
