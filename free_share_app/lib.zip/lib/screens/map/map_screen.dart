import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../providers/auth_provider.dart';
import '../../providers/map_provider.dart';
import '../../providers/item_provider.dart';
import '../../models/item_model.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _initializeMap();
  }

  Future<void> _initializeMap() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final mapProvider = Provider.of<MapProvider>(context, listen: false);
      await mapProvider.getCurrentLocation();
      
      if (mapProvider.currentPosition != null) {
        final itemProvider = Provider.of<ItemProvider>(context, listen: false);
        await itemProvider.loadNearbyItems(
          mapProvider.currentPosition!.latitude,
          mapProvider.currentPosition!.longitude,
        );
        _updateMarkers();
      } else {
        setState(() {
          _errorMessage = '無法獲取當前位置，請檢查位置權限設定';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = '載入地圖時發生錯誤：${e.toString()}';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _updateMarkers() {
    final itemProvider = Provider.of<ItemProvider>(context, listen: false);
    Set<Marker> markers = {};
    
    for (ItemModel item in itemProvider.nearbyItems) {
      // 只顯示狀態為 active 且可用的物品
      if (item.status == 'active' && item.isAvailable && !item.isReported) {
        markers.add(
          Marker(
            markerId: MarkerId(item.id),
            position: LatLng(item.location.latitude, item.location.longitude),
            onTap: () => _onMarkerTapped(item),
            infoWindow: InfoWindow(
              title: item.tag,
              snippet: '點擊查看詳情',
            ),
            icon: BitmapDescriptor.defaultMarkerWithHue(
              BitmapDescriptor.hueOrange,
            ),
          ),
        );
      }
    }
    
    setState(() {
      _markers = markers;
    });
  }

  void _onMarkerTapped(ItemModel item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.6,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Column(
          children: [
            // 拖拉指示條
            Container(
              margin: EdgeInsets.only(top: 8),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 物品基本資訊
                    Row(
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            image: item.imageUrls.isNotEmpty
                                ? DecorationImage(
                                    image: NetworkImage(item.imageUrls.first),
                                    fit: BoxFit.cover,
                                  )
                                : null,
                            color: Colors.grey[300],
                          ),
                          child: item.imageUrls.isEmpty
                              ? Icon(Icons.image, color: Colors.grey[600])
                              : null,
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.symmetric(vertical: 4),
                                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.green[100],
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  item.tag,
                                  style: TextStyle(
                                    color: Colors.green[700],
                                    fontWeight: FontWeight.w500,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    
                    SizedBox(height: 16),
                    
                    // 物品描述
                    Text(
                      '物品描述',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey[800],
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      item.description,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                        height: 1.4,
                      ),
                    ),
                    
                    SizedBox(height: 16),
                    
                    // 物品圖片列表（如果有多張）
                    if (item.imageUrls.length > 1) ...[
                      Text(
                        '更多圖片',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[800],
                        ),
                      ),
                      SizedBox(height: 8),
                      Container(
                        height: 80,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: item.imageUrls.length,
                          itemBuilder: (context, index) {
                            return Container(
                              width: 80,
                              height: 80,
                              margin: EdgeInsets.only(right: 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                image: DecorationImage(
                                  image: NetworkImage(item.imageUrls[index]),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 16),
                    ],
                    
                    // 發布時間
                    Text(
                      '發布時間：${_formatDateTime(item.createdAt)}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[500],
                      ),
                    ),
                    
                    SizedBox(height: 24),
                    
                    // 操作按鈕
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.pop(context);
                              context.push('/item-detail/${item.id}');
                            },
                            icon: Icon(Icons.visibility),
                            label: Text('查看詳情'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _showReportDialog(item),
                            icon: Icon(Icons.flag),
                            label: Text('檢舉'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.red,
                              padding: EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    
                    SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showReportDialog(ItemModel item) {
    Navigator.pop(context); // 關閉底部彈窗
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('檢舉物品'),
        content: Text('確定要檢舉這個物品嗎？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('取消'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _reportItem(item);
            },
            child: Text('確定檢舉', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<void> _reportItem(ItemModel item) async {
    try {
      final itemProvider = Provider.of<ItemProvider>(context, listen: false);
      await itemProvider.reportItem(item.id);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已檢舉該物品')),
      );
      
      // 重新載入標記
      _updateMarkers();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('檢舉失敗：${e.toString()}')),
      );
    }
  }

  String _formatDateTime(String timestamp) {
    try {
      final dateTime = DateTime.parse(timestamp);
      final now = DateTime.now();
      final difference = now.difference(dateTime);
      
      if (difference.inDays > 0) {
        return '${difference.inDays} 天前';
      } else if (difference.inHours > 0) {
        return '${difference.inHours} 小時前';
      } else if (difference.inMinutes > 0) {
        return '${difference.inMinutes} 分鐘前';
      } else {
        return '剛剛';
      }
    } catch (e) {
      return timestamp;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('物品地圖'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () => context.push('/search'),
          ),
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _initializeMap,
          ),
        ],
      ),
      body: Stack(
        children: [
          // 地圖主體
          Consumer2<MapProvider, ItemProvider>(
            builder: (context, mapProvider, itemProvider, child) {
              if (mapProvider.currentPosition == null) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 16),
                      Text('正在獲取位置...'),
                    ],
                  ),
                );
              }

              return GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: LatLng(
                    mapProvider.currentPosition!.latitude,
                    mapProvider.currentPosition!.longitude,
                  ),
                  zoom: 15.0,
                ),
                onMapCreated: (GoogleMapController controller) {
                  _mapController = controller;
                },
                markers: _markers,
                myLocationEnabled: true,
                myLocationButtonEnabled: true,
                zoomControlsEnabled: false,
                mapToolbarEnabled: false,
                circles: {
                  Circle(
                    circleId: CircleId('search_radius'),
                    center: LatLng(
                      mapProvider.currentPosition!.latitude,
                      mapProvider.currentPosition!.longitude,
                    ),
                    radius: 2000, // 2公里
                    strokeColor: Colors.blue.withOpacity(0.3),
                    strokeWidth: 2,
                    fillColor: Colors.blue.withOpacity(0.1),
                  ),
                },
              );
            },
          ),

          // 載入中覆蓋層
          if (_isLoading)
            Container(
              color: Colors.black26,
              child: Center(
                child: Card(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 16),
                        Text('正在載入附近的物品...'),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          // 錯誤訊息
          if (_errorMessage != null)
            Positioned(
              top: 16,
              left: 16,
              right: 16,
              child: Card(
                color: Colors.red[100],
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Icon(Icons.error, color: Colors.red),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: Colors.red[800]),
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.close),
                        onPressed: () {
                          setState(() {
                            _errorMessage = null;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // 底部資訊卡片
          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: Consumer<ItemProvider>(
              builder: (context, itemProvider, child) {
                final activeItems = itemProvider.nearbyItems
                    .where((item) => item.status == 'active' && item.isAvailable && !item.isReported)
                    .length;

                return Card(
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Row(
                      children: [
                        Icon(Icons.location_on, color: Colors.blue),
                        SizedBox(width: 8),
                        Text('附近 2 公里內有 $activeItems 個物品'),
                        Spacer(),
                        Text(
                          '點擊標記查看詳情',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.push('/add-item'),
        child: Icon(Icons.add),
        backgroundColor: Colors.blue,
        tooltip: '上架物品',
      ),
    );
  }
}
