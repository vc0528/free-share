import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<UserModel?> getCurrentUserData() async {
    User? user = _auth.currentUser;
    if (user != null) {
      DocumentSnapshot doc = await _firestore
          .collection('users')
          .doc(user.uid)
          .get();
      
      if (doc.exists) {
        return UserModel.fromFirestore(doc);
      }
    }
    return null;
  }

  Future<UserCredential?> signInWithEmailAndPassword(
      String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      
      // 更新最後活動時間
      await _updateLastActive(result.user!.uid);
      
      return result;
    } catch (e) {
      throw e;
    }
  }

  Future<UserCredential?> createUserWithEmailAndPassword(
      String email, String password, String username) async {
    try {
      // 檢查用戶名是否已存在
      bool usernameExists = await _checkUsernameExists(username);
      if (usernameExists) {
        throw Exception('用戶名已存在');
      }

      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      // 創建用戶資料
      UserModel newUser = UserModel(
        uid: result.user!.uid,
        email: email.trim(),
        username: username.trim(),
        createdAt: DateTime.now(),
        lastActive: DateTime.now(),
        rating: RatingData(),
        transactionStats: TransactionStats(
          joinDate: DateTime.now(),
        ),
        preferences: UserPreferences(),
      );

      await _firestore
          .collection('users')
          .doc(result.user!.uid)
          .set(newUser.toFirestore());

      return result;
    } catch (e) {
      throw e;
    }
  }

  Future<bool> _checkUsernameExists(String username) async {
    QuerySnapshot query = await _firestore
        .collection('users')
        .where('username', isEqualTo: username.trim())
        .limit(1)
        .get();
    
    return query.docs.isNotEmpty;
  }

  Future<void> _updateLastActive(String uid) async {
    await _firestore.collection('users').doc(uid).update({
      'lastActive': Timestamp.now(),
    });
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  Future<void> updateUserLocation(double latitude, double longitude) async {
    User? user = _auth.currentUser;
    if (user != null) {
      LocationData locationData = LocationData(
        latitude: latitude,
        longitude: longitude,
        lastUpdated: DateTime.now(),
      );

      await _firestore.collection('users').doc(user.uid).update({
        'location': locationData.toMap(),
      });
    }
  }

  Future<UserModel?> getUserById(String uid) async {
    try {
      DocumentSnapshot doc = await _firestore
          .collection('users')
          .doc(uid)
          .get();
      
      if (doc.exists) {
        return UserModel.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      print('Error getting user: $e');
      return null;
    }
  }
}
